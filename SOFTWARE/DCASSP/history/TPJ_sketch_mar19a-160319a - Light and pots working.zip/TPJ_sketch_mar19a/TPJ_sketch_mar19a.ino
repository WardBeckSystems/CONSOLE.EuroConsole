#include <Adafruit_NeoPixel.h>





#define FNT_NEO_PIXEL_PIN 48
#define N_PIXELS 5


//neopixel
#define FNT_NEO_PIXEL_SEL 4
#define FNT_NEO_PIXEL_SUN 3
#define FNT_NEO_PIXEL_SKY 2
#define FNT_NEO_PIXEL_GRASS 1
#define FNT_NEO_PIXEL_EARTH 0






//Potentionmeters

#define FNT_POT_SUN_PIN A0
#define FNT_POT_SKY_PIN A1
#define FNT_POT_GRASS_PIN A6
#define FNT_POT_EARTH_PIN A12
#define FDR_POT_POSITION_PIN  A14
#define FDR_POT_SLIDE_PIN A15

int FNT_POT_EARTH_STATE;
int FNT_POT_GRASS_STATE;
int FNT_POT_SKY_STATE;
int FNT_POT_SUN_STATE;
int FDR_POT_POSITION_STATE;
int FDR_POT_SLIDE_STATE;


Adafruit_NeoPixel FNT_NEO_PIXEL = Adafruit_NeoPixel(N_PIXELS, FNT_NEO_PIXEL_PIN, NEO_GRB + NEO_KHZ800);


void setup() {
 

Serial.begin(9600);

  
pinMode(FDR_POT_POSITION_PIN,INPUT);
pinMode(FDR_POT_SLIDE_PIN,INPUT);
pinMode(FNT_POT_EARTH_PIN,INPUT);
pinMode(FNT_POT_GRASS_PIN,INPUT);
pinMode(FNT_POT_SKY_PIN,INPUT);
pinMode(FNT_POT_SUN_PIN,INPUT);

  FNT_NEO_PIXEL.begin();
  FNT_NEO_PIXEL.show(); // Initialize all pixels to 'off'
}

void loop() {
 CheckAnalog();                    
 DisplayValues();
 UpdateNeopixel();
}

void UpdateNeopixel() {
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SEL, ((float)FDR_POT_SLIDE_STATE/1024)*255, 0, 0) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SUN, ((float)FNT_POT_SUN_STATE/1024)*244, ((float)FNT_POT_SUN_STATE/1024)*144, ((float)FNT_POT_SUN_STATE/1024)*44) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SKY, 0, 0, ((float)FNT_POT_SKY_STATE/1024)*255) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_GRASS, 0, ((float)FNT_POT_GRASS_STATE/1024)*255, 0) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_EARTH, ((float)FNT_POT_EARTH_STATE/1024)*105, ((float)FNT_POT_EARTH_STATE/1024)*69, 0) ;
  FNT_NEO_PIXEL.show();
};


void CheckAnalog(){
  FDR_POT_POSITION_STATE = analogRead(FDR_POT_POSITION_PIN);
  FDR_POT_SLIDE_STATE = analogRead(FDR_POT_SLIDE_PIN);
  FNT_POT_EARTH_STATE = analogRead(FNT_POT_EARTH_PIN);
  FNT_POT_GRASS_STATE = analogRead(FNT_POT_GRASS_PIN);
  FNT_POT_SKY_STATE = analogRead(FNT_POT_SKY_PIN);
  FNT_POT_SUN_STATE = analogRead(FNT_POT_SUN_PIN);
  }
void DisplayValues(){


Serial.print(FDR_POT_POSITION_STATE,DEC);  Serial.print("\t"); 
Serial.print(FDR_POT_SLIDE_STATE,DEC);  Serial.print("\t"); 
Serial.print(FNT_POT_EARTH_STATE,DEC);     Serial.print("\t"); 
Serial.print(FNT_POT_GRASS_STATE,DEC);      Serial.print("\t"); 
Serial.print(FNT_POT_SKY_STATE,DEC);   Serial.print("\t"); 
Serial.print(FNT_POT_SUN_STATE,DEC);   Serial.print("\t"); 
Serial.println("\n");      // prints another carriage return

}


