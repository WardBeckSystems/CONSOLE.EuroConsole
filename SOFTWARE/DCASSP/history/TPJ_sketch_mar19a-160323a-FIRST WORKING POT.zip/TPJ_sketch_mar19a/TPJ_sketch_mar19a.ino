#include <Adafruit_NeoPixel.h>
#include <Wire.h>




#define FNT_NEO_PIXEL_PIN 48
#define N_PIXELS 5


//neopixel
#define FNT_NEO_PIXEL_SEL 4
#define FNT_NEO_PIXEL_SUN 3
#define FNT_NEO_PIXEL_SKY 2
#define FNT_NEO_PIXEL_GRASS 1
#define FNT_NEO_PIXEL_EARTH 0

//LED Lights
#define  FDR_LED_KEY_CHON_PIN  25
#define FDR_LED_KEY_ONLY_PIN  22
#define FDR_LED_KEY_SEL_PIN 23
#define  FNT_LED_KEY_EARTH_PIN 39
#define FNT_LED_KEY_GRASS_PIN 41
#define FNT_LED_KEY_SEL_PIN 50
#define FNT_LED_KEY_SKY_PIN 49
#define FNT_LED_KEY_SUN_PIN 51

//Potentionmeters

#define FNT_POT_SUN_PIN A0
#define FNT_POT_SKY_PIN A1
#define FNT_POT_GRASS_PIN A6
#define FNT_POT_EARTH_PIN A12
#define FDR_POT_POSITION_PIN  A14
#define FDR_POT_SLIDE_PIN A15

// KEYS
#define  FDR_KEY_CHON_PIN  27
#define FDR_KEY_ONLY_PIN  31
#define FDR_KEY_SEL_PIN 29
#define  FNT_KEY_EARTH_PIN 37
#define FNT_KEY_GRASS_PIN 35
#define FNT_KEY_SEL_PIN 52
#define FNT_KEY_SKY_PIN 47
#define FNT_KEY_SUN_PIN 45

int FNT_POT_EARTH_STATE;
int FNT_POT_GRASS_STATE;
int FNT_POT_SKY_STATE;
int FNT_POT_SUN_STATE;
int FDR_POT_POSITION_STATE;
int FDR_POT_SLIDE_STATE;

//FADER LED PANEL
int  FDR_LED_KEY_CHON_STATE = 1;
int FDR_LED_KEY_ONLY_STATE  = 1 ;
int FDR_LED_KEY_SEL_STATE  = 1;

// FADER KEY
int  FDR_KEY_CHON_STATE;
int FDR_KEY_ONLY_STATE;
int FDR_KEY_SEL_STATE;

// FRONT LED
int  FNT_LED_KEY_EARTH_STATE = 1 ;
int FNT_LED_KEY_GRASS_STATE = 1;
int FNT_LED_KEY_SEL_STATE = 1;
int FNT_LED_KEY_SKY_STATE = 1;
int FNT_LED_KEY_SUN_STATE = 1;

//FRONT KEYS
int  FNT_KEY_EARTH_STATE ;
int FNT_KEY_GRASS_STATE ;
int FNT_KEY_SEL_STATE ;
int FNT_KEY_SKY_STATE ;
int FNT_KEY_SUN_STATE ;

//Digital POTS
byte attenuation = 32;                            // Attenuation value of volume potentiometer gangs. Initially set to minimum volume.
byte tempattenuation = 0;                         // Holds attenuation value for second pot bitwise operation
byte PotScaler = 64;

Adafruit_NeoPixel FNT_NEO_PIXEL = Adafruit_NeoPixel(N_PIXELS, FNT_NEO_PIXEL_PIN, NEO_GRB + NEO_KHZ800);


void setup() {


  Serial.begin(9600);


  Wire.begin(); // join i2c bus (address optional for master)

  Wire.beginTransmission(40);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write(0x87);
  Wire.endTransmission();
  delay(500);

  Wire.beginTransmission(41);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write(0x87);
  Wire.endTransmission();
  delay(500);

  Wire.beginTransmission(41);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write(0x87);
  Wire.endTransmission();
  delay(500);

  Wire.beginTransmission(41);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write(0x87);
  Wire.endTransmission();
  delay(500);

  pinMode(FDR_POT_POSITION_PIN, INPUT);
  pinMode(FDR_POT_SLIDE_PIN, INPUT);
  pinMode(FNT_POT_EARTH_PIN, INPUT);
  pinMode(FNT_POT_GRASS_PIN, INPUT);
  pinMode(FNT_POT_SKY_PIN, INPUT);
  pinMode(FNT_POT_SUN_PIN, INPUT);

  //FADER LED
  pinMode(FDR_LED_KEY_CHON_PIN, OUTPUT);
  pinMode(FDR_LED_KEY_ONLY_PIN, OUTPUT);
  pinMode(FDR_LED_KEY_SEL_PIN, OUTPUT);

  //FADER KEY
  pinMode(FDR_KEY_CHON_PIN, INPUT);
  pinMode(FDR_KEY_ONLY_PIN, INPUT);
  pinMode(FDR_KEY_SEL_PIN, INPUT);


  //FRONT LED

  pinMode(FNT_LED_KEY_EARTH_PIN, OUTPUT);
  pinMode(FNT_LED_KEY_GRASS_PIN, OUTPUT);
  pinMode(FNT_LED_KEY_SEL_PIN, OUTPUT);
  pinMode(FNT_LED_KEY_SKY_PIN, OUTPUT);
  pinMode(FNT_LED_KEY_SUN_PIN, OUTPUT);

  //FRONT KEY
  pinMode(FNT_KEY_EARTH_PIN, INPUT);
  pinMode(FNT_KEY_GRASS_PIN, INPUT);
  pinMode(FNT_KEY_SEL_PIN, INPUT);
  pinMode(FNT_KEY_SKY_PIN, INPUT);
  pinMode(FNT_KEY_SUN_PIN, INPUT);


  FNT_NEO_PIXEL.begin();
  FNT_NEO_PIXEL.show(); // Initialize all pixels to 'off'
}

void loop() {
  CheckAnalog();
  CheckKeys();
  LEDupdate();
  DisplayKeyValues();


  UpdateNeopixel();










  ////////////////////

  changeVolume();


/*///PRINT OUT SCALLED Values 64
 * 
 *Serial.print((int)((float)FDR_POT_POSITION_STATE/1024*PotScaler), DEC);  Serial.print("\t");
  Serial.print((int)((float)FDR_POT_SLIDE_STATE/1024*PotScaler), DEC);  Serial.print("\t");
  Serial.print((int)((float)FNT_POT_EARTH_STATE/1024*PotScaler), DEC);     Serial.print("\t");
  Serial.print((int)((float)FNT_POT_GRASS_STATE/1024*PotScaler), DEC);      Serial.print("\t");
  Serial.print((int)((float)FNT_POT_SKY_STATE/1024*PotScaler), DEC);   Serial.print("\t");
  Serial.print((int)((float)FNT_POT_SUN_STATE/1024*PotScaler), DEC);   Serial.print("\t");
  Serial.println("\n");      // prints another carriage return
  // Update second potentiometer gang. Same process, where pot address is now: 01 ######.
  // (each I2C transmission should be started stopped individually)
*/
}



void changeVolume()
{
  // Update first potentiometer gang, where pot address is first two bits of attenuation: 00 ######
  Wire.beginTransmission(0x28);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  //Wire.write(byte(0x00));            // sends instruction byte
  Wire.write((int)((float)FNT_POT_SUN_STATE/1024*PotScaler));                    // Write wiper value
  Wire.endTransmission();                     // Stop transmitting


  Wire.beginTransmission(0x29);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write((int)((float)FNT_POT_SKY_STATE/1024*PotScaler));                    // Write wiper value
  Wire.endTransmission();                     // Stop transmitting


  Wire.beginTransmission(0x2A);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write((int)((float)FNT_POT_GRASS_STATE/1024*PotScaler));                    // Write wiper value
  Wire.endTransmission();                     // Stop transmitting

  Wire.beginTransmission(0x2B);                 // Transmit to DS1808, device #40 (0x28) = 0101 000, LSB is auto sent by Arduino Wire
  Wire.write((int)((float)FNT_POT_EARTH_STATE/1024*PotScaler));                    // Write wiper value
  Wire.endTransmission();                     // Stop transmitting




}



void CheckKeys()

{
  FDR_LED_KEY_CHON_STATE = digitalRead(FDR_KEY_CHON_PIN);
  FDR_LED_KEY_ONLY_STATE = digitalRead(FDR_KEY_ONLY_PIN);
  FDR_LED_KEY_SEL_STATE = digitalRead(FDR_KEY_SEL_PIN);

  FNT_LED_KEY_EARTH_STATE = digitalRead(FNT_KEY_EARTH_PIN);
  FNT_LED_KEY_GRASS_STATE = digitalRead(FNT_KEY_GRASS_PIN);
  FNT_LED_KEY_SEL_STATE = digitalRead(FNT_KEY_SEL_PIN);
  FNT_LED_KEY_SKY_STATE = digitalRead(FNT_KEY_SKY_PIN);
  FNT_LED_KEY_SUN_STATE = digitalRead(FNT_KEY_SUN_PIN);

}



void LEDupdate()
{
  digitalWrite(FDR_LED_KEY_CHON_PIN, FDR_LED_KEY_CHON_STATE);
  digitalWrite(FDR_LED_KEY_ONLY_PIN, FDR_LED_KEY_ONLY_STATE);
  digitalWrite(FDR_LED_KEY_SEL_PIN, FDR_LED_KEY_SEL_STATE);


  digitalWrite(FNT_LED_KEY_EARTH_PIN, FNT_LED_KEY_EARTH_STATE);
  digitalWrite(FNT_LED_KEY_GRASS_PIN, FNT_LED_KEY_GRASS_STATE);
  digitalWrite(FNT_LED_KEY_SEL_PIN, FNT_LED_KEY_SEL_STATE);
  digitalWrite(FNT_LED_KEY_SKY_PIN, FNT_LED_KEY_SKY_STATE);
  digitalWrite(FNT_LED_KEY_SUN_PIN, FNT_LED_KEY_SUN_STATE);

}



void CheckAnalog() {
  FDR_POT_POSITION_STATE = analogRead(FDR_POT_POSITION_PIN);
  FDR_POT_SLIDE_STATE = analogRead(FDR_POT_SLIDE_PIN);
  FNT_POT_EARTH_STATE = analogRead(FNT_POT_EARTH_PIN);
  FNT_POT_GRASS_STATE = analogRead(FNT_POT_GRASS_PIN);
  FNT_POT_SKY_STATE = analogRead(FNT_POT_SKY_PIN);
  FNT_POT_SUN_STATE = analogRead(FNT_POT_SUN_PIN);
}



void UpdateNeopixel() {
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SEL, ((float)FDR_POT_SLIDE_STATE / 1024) * 255, 0, 0) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SUN, ((float)FNT_POT_SUN_STATE / 1024) * 244, ((float)FNT_POT_SUN_STATE / 1024) * 144, ((float)FNT_POT_SUN_STATE / 1024) * 44) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_SKY, 0, 0, ((float)FNT_POT_SKY_STATE / 1024) * 255) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_GRASS, 0, ((float)FNT_POT_GRASS_STATE / 1024) * 255, 0) ;
  FNT_NEO_PIXEL.setPixelColor(FNT_NEO_PIXEL_EARTH, ((float)FNT_POT_EARTH_STATE / 1024) * 105, ((float)FNT_POT_EARTH_STATE / 1024) * 69, 0) ;
  FNT_NEO_PIXEL.show();
};



void DisplayKeyValues() {
  Serial.print(FNT_KEY_EARTH_STATE, DEC);
  Serial.print(FNT_KEY_GRASS_STATE, DEC);
  Serial.print(FNT_KEY_SEL_STATE, DEC);
  Serial.print(FNT_KEY_SKY_STATE, DEC);
  Serial.print(FNT_KEY_SUN_STATE, DEC);
}


void DisplayPotValues() {
  Serial.print(FDR_POT_POSITION_STATE, DEC);  Serial.print("\t");
  Serial.print(FDR_POT_SLIDE_STATE, DEC);  Serial.print("\t");
  Serial.print(FNT_POT_EARTH_STATE, DEC);     Serial.print("\t");
  Serial.print(FNT_POT_GRASS_STATE, DEC);      Serial.print("\t");
  Serial.print(FNT_POT_SKY_STATE, DEC);   Serial.print("\t");
  Serial.print(FNT_POT_SUN_STATE, DEC);   Serial.print("\t");
  Serial.println("\n");      // prints another carriage return

}


